This directory will contain translation (.po) files once you run the
'translation' job in your project.

