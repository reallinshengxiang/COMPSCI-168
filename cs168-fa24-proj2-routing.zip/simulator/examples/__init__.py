"""
Various examples and tests
"""
